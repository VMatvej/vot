
using System.Net.Http.Json; using ProductApi.Models;
namespace ProductWeb.Services;

public class ApiService
{
    private readonly HttpClient _httpClient;
    public ApiService(HttpClient httpClient)
    {
        _httpClient = httpClient;
        _httpClient.BaseAddress = new Uri("http://localhost:5235"); 
    }
    public async Task<List<Product>> GetProductsAsync() =>
        await _httpClient.GetFromJsonAsync<List<Product>>("api/products") ?? new();
    public async Task<Product?> GetProductAsync(int id) =>
        await _httpClient.GetFromJsonAsync<Product>($"api/products/{id}");
    public async Task AddProductAsync(Product product) =>
        await _httpClient.PostAsJsonAsync("api/products", product);
    public async Task UpdateProductAsync(int id, Product product) =>
        await _httpClient.PutAsJsonAsync($"api/products/{id}", product);
    public async Task DeleteProductAsync(int id) =>
        await _httpClient.DeleteAsync($"api/products/{id}");
}