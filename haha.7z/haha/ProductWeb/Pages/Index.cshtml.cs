using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProductApi.Models;
using ProductWeb.Services;


namespace ProductWeb.Pages;

public class IndexModel : PageModel
{
    private readonly ApiService _apiService;
    public List<Product> Product { get; set; } = new();

    public IndexModel(ApiService apiService) => _apiService = apiService;

    public async Task OnGetAsync() => Product = await _apiService.GetProductsAsync();
}
