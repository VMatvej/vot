
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages; using ProductApi.Models;
using ProductWeb.Services;
namespace ProductWEB. Pages
{
    public class CreateModel : PageModel
    {
        private readonly ApiService _apiService;
        [BindProperty]


        public Product Product { get; set; } = new();
        public CreateModel(ApiService apiService) => _apiService = apiService;
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();
            await _apiService.AddProductAsync(Product);
            return RedirectToPage("./Index");
        }
    }
}