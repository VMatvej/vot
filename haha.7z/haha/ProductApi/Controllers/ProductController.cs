using Microsoft.AspNetCore.Mvc;
using ProductApi.Models;

namespace ProductApi.Controllers;

[ApiController]
[Route("api/products")]
public class ProductController : ControllerBase
{
    private static List<Product> _products = new()
    {
        new Product{Id=1,Name="Laptop",Price=999.99m,Description="High performance laptop"},
        new Product{Id=2,Name="Smartphone",Price=699.99m,Description="Latest smartphone model"},
        new Product{Id=3,Name="Tablet",Price=349.99m,Description="Portable tablet device"}
    };

    [HttpGet]
    public ActionResult<IEnumerable<Product>> Get()
    {
        return _products;
    }

    [HttpGet("{id}")]
    public ActionResult<Product> Get(int id)
    {
        var product = _products.FirstOrDefault(p => p.Id == id);
        return product == null ? NotFound() : product;
    }

    [HttpPost]
    public ActionResult<Product> Post(Product product)
    {
        product.Id = _products.Max(p => p.Id) + 1;
        _products.Add(product);
        return CreatedAtAction(nameof(Get), new { id = product.Id }, product);
    }

    [HttpPut("{id}")]
    public IActionResult Put(int id, Product product)
    {
        var existing = _products.FirstOrDefault(p => p.Id == id);
        if (existing == null) return NotFound();
        existing.Name = product.Name;
        existing.Price = product.Price;
        existing.Description = product.Description;
        return NoContent();
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        var product = _products.FirstOrDefault(p => p.Id == id);
        if (product == null) return NotFound();
        _products.Remove(product);
        return NoContent();
    }
}
